import json, math, shutil, subprocess, re
from pathlib import Path

def command(args):
    p = subprocess.run(args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    if p.returncode:
        raise RuntimeError(p.stderr[-1800:] or "Command failed")
    return p.stdout

def probe_video(path):
    raw = command(["ffprobe","-v","error","-show_entries","format=duration:stream=codec_type,width,height","-of","json",str(path)])
    data = json.loads(raw); duration = float(data["format"]["duration"])
    v = next((s for s in data["streams"] if s["codec_type"]=="video"), {})
    return {"duration": round(duration,2), "width":v.get("width"), "height":v.get("height"),
            "duration_text": f"{int(duration//60)}m {int(duration%60)}s"}

def scene_scores(path, duration, step=2.0):
    """Fast FFmpeg scene-change scan; score is a heuristic, not a guarantee of virality."""
    expr = "select='gt(scene,0.12)',showinfo"
    p = subprocess.run(["ffmpeg","-hide_banner","-i",str(path),"-vf",expr,"-an","-f","null","-"],
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    times = []
    for line in p.stderr.splitlines():
        m = re.search(r"pts_time:([0-9.]+)", line)
        if m:
            t = float(m.group(1))
            if 0 < t < duration: times.append(t)
    return times

def audio_energy(path, duration, bucket=1.0):
    """Return approximate per-second audio activity using FFmpeg astats-free RMS windows."""
    # silencedetect yields activity intervals and is more robust on mobile than Python audio libraries.
    p = subprocess.run(["ffmpeg","-hide_banner","-i",str(path),"-af","silencedetect=noise=-32dB:d=0.35",
                        "-f","null","-"], stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
    silences = []
    for line in p.stderr.splitlines():
        a = re.search(r"silence_start: ([0-9.]+)", line)
        b = re.search(r"silence_end: ([0-9.]+)", line)
        if a: silences.append([float(a.group(1)), duration])
        if b and silences: silences[-1][1] = float(b.group(1))
    # Score each one-second bucket by whether it is not inside a detected silence.
    scores=[]
    for t in range(0, max(1, math.ceil(duration))):
        mid=t+0.5
        silent=any(s<=mid<e for s,e in silences)
        scores.append(0.08 if silent else 0.65)
    return scores

def rank_windows(path, duration, clip_seconds, mode):
    if mode == "even":
        return list(range(0, max(1, int(duration)), clip_seconds))[:30]
    scenes=scene_scores(path,duration)
    energy=audio_energy(path,duration)
    # Candidate start points on a coarse grid; reward speech/non-silence and nearby scene changes.
    stride=max(5, min(15, clip_seconds//2))
    candidates=list(range(0, max(1,int(duration-clip_seconds+1)), stride))
    if not candidates: candidates=[0]
    ranked=[]
    for start in candidates:
        end=min(duration,start+clip_seconds)
        lo=max(0,int(start)); hi=min(len(energy),int(math.ceil(end)))
        activity=sum(energy[lo:hi])/max(1,hi-lo)
        transitions=sum(1 for x in scenes if start <= x <= end)
        # Slightly prefer sections with active audio and visual changes; spread later.
        score=activity + min(transitions,8)*0.035
        ranked.append((score,start))
    ranked.sort(reverse=True)
    selected=[]
    for _, start in ranked:
        if all(abs(start-s)>=clip_seconds*0.65 for s in selected):
            selected.append(start)
    return sorted(selected)

def detect_face_center(video, start, duration):
    """Try OpenCV Haar face detection; return normalized center x, or None."""
    try:
        import cv2
        cap=cv2.VideoCapture(str(video))
        cap.set(cv2.CAP_PROP_POS_MSEC, (start+duration/2)*1000)
        ok, frame=cap.read(); cap.release()
        if not ok: return None
        gray=cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
        cascade=cv2.data.haarcascades+"haarcascade_frontalface_default.xml"
        detector=cv2.CascadeClassifier(cascade)
        faces=detector.detectMultiScale(gray,1.1,4,minSize=(40,40))
        if len(faces):
            x,y,w,h=max(faces,key=lambda r:r[2]*r[3])
            return (x+w/2)/frame.shape[1]
    except Exception:
        pass
    return None

def subtitle_file(video, outdir, language="auto"):
    """Optional Whisper subtitles. Install faster-whisper separately to enable."""
    try:
        from faster_whisper import WhisperModel
    except Exception:
        return None, "faster-whisper is not installed; subtitles skipped."
    model=WhisperModel("tiny", device="cpu", compute_type="int8")
    lang=None if language=="auto" else language
    segments, info=model.transcribe(str(video), language=lang, vad_filter=True)
    srt=outdir/"captions.srt"
    def stamp(sec):
        ms=int(sec*1000); h=ms//3600000; ms%=3600000; m=ms//60000; ms%=60000; s=ms//1000; ms%=1000
        return f"{h:02}:{m:02}:{s:02},{ms:03}"
    with srt.open("w",encoding="utf-8") as f:
        for i,seg in enumerate(segments,1):
            f.write(f"{i}\n{stamp(seg.start)} --> {stamp(seg.end)}\n{seg.text.strip()}\n\n")
    return srt, None

def process_video(source, outdir, clip_seconds=30, max_clips=10, aspect="9:16",
                  mode="highlights", captions=False, face_crop=False, language="auto"):
    outdir.mkdir(parents=True,exist_ok=True)
    info=probe_video(source); duration=info["duration"]
    starts=rank_windows(source,duration,clip_seconds,mode)[:max_clips]
    srt=None; warning=None
    if captions:
        srt,warning=subtitle_file(source,outdir,language)
    clips=[]; report={"source":str(source.name),"video":info,"mode":mode,"clip_seconds":clip_seconds,
                      "aspect":aspect,"clips":[],"notes":[]}
    if warning: report["notes"].append(warning)
    for i,start in enumerate(starts,1):
        length=min(clip_seconds,duration-start)
        if length < 3: continue
        vf=[]
        if aspect=="9:16":
            # Crop to 9:16; face center can move the crop window toward the detected face.
            target_ratio=9/16
            if face_crop:
                cx=detect_face_center(source,start,length)
            else: cx=None
            if info["width"] and info["height"]:
                crop_w=int(info["height"]*target_ratio)
                if crop_w>info["width"]:
                    crop_h=int(info["width"]/target_ratio)
                    y="(ih-oh)/2"
                    vf.append(f"crop=iw:{crop_h}:0:{y}")
                else:
                    x=f"max(0,min(iw-ow,{int((cx or 0.5)*info['width'])}-ow/2))"
                    vf.append(f"crop={crop_w}:ih:{x}:0")
            vf.append("scale=1080:1920:force_original_aspect_ratio=decrease,pad=1080:1920:(ow-iw)/2:(oh-ih)/2")
        elif aspect=="1:1":
            vf += ["crop=min(iw\\,ih):min(iw\\,ih)","scale=1080:1080"]
        else:
            vf += ["scale=1920:1080:force_original_aspect_ratio=decrease","pad=1920:1080:(ow-iw)/2:(oh-ih)/2"]
        if srt:
            # FFmpeg subtitles filter path escaping for Android/Linux paths.
            srtpath=str(srt.resolve()).replace("\\","\\\\").replace(":","\\:").replace("'","\\'")
            vf.append(f"subtitles='{srtpath}':force_style='FontSize=18,Outline=2,Alignment=2,MarginV=70'")
        dest=outdir/f"clip_{i:02}.mp4"
        cmd=["ffmpeg","-y","-ss",str(start),"-i",str(source),"-t",str(length),"-vf",",".join(vf),
             "-c:v","libx264","-preset","veryfast","-crf","23","-c:a","aac","-b:a","128k",
             "-movflags","+faststart",str(dest)]
        command(cmd)
        clips.append(dest)
        report["clips"].append({"file":dest.name,"start_seconds":round(start,2),
                                "end_seconds":round(start+length,2),"duration_seconds":round(length,2)})
    report_path=outdir/"clip_report.json"
    report_path.write_text(json.dumps(report,indent=2),encoding="utf-8")
    return {"clips":clips,"captions":[srt] if srt else [],"report":report}
