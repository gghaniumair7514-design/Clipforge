import os, uuid, json, zipfile, shutil, threading, subprocess
from pathlib import Path
from flask import Flask, render_template, request, redirect, url_for, send_file, flash, jsonify
from werkzeug.utils import secure_filename
from clipforge import process_video, probe_video

BASE = Path(__file__).resolve().parent
UPLOADS = BASE / "uploads"
OUTPUTS = BASE / "outputs"
UPLOADS.mkdir(exist_ok=True); OUTPUTS.mkdir(exist_ok=True)
ALLOWED = {".mp4", ".mov", ".mkv", ".webm", ".avi", ".m4v"}
app = Flask(__name__)
app.secret_key = os.environ.get("CLIPFORGE_SECRET", "change-this-local-secret")
JOBS = {}
LOCK = threading.Lock()

def run_job(job_id, source, opts):
    try:
        with LOCK: JOBS[job_id]["status"] = "processing"
        result = process_video(source, OUTPUTS / job_id, **opts)
        zip_path = OUTPUTS / f"{job_id}.zip"
        with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
            for p in result["clips"]:
                z.write(p, p.name)
            if result.get("captions"):
                for p in result["captions"]:
                    z.write(p, f"captions/{p.name}")
            z.writestr("clip_report.json", json.dumps(result["report"], indent=2))
        with LOCK:
            JOBS[job_id].update(status="done", zip=str(zip_path), report=result["report"])
    except Exception as e:
        with LOCK: JOBS[job_id].update(status="error", error=str(e))

@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        f = request.files.get("video")
        if not f or not f.filename:
            flash("Choose a video first."); return redirect(url_for("index"))
        ext = Path(secure_filename(f.filename)).suffix.lower()
        if ext not in ALLOWED:
            flash("Unsupported format. Use MP4, MOV, MKV, WEBM, AVI or M4V."); return redirect(url_for("index"))
        job_id = uuid.uuid4().hex[:10]
        source = UPLOADS / f"{job_id}{ext}"
        f.save(source)
        try:
            info = probe_video(source)
        except Exception as e:
            source.unlink(missing_ok=True)
            flash(f"Could not read this video: {e}"); return redirect(url_for("index"))
        opts = {
            "clip_seconds": int(request.form.get("clip_seconds", 30)),
            "max_clips": int(request.form.get("max_clips", 10)),
            "aspect": request.form.get("aspect", "9:16"),
            "mode": request.form.get("mode", "highlights"),
            "captions": request.form.get("captions") == "on",
            "face_crop": request.form.get("face_crop") == "on",
            "language": request.form.get("language", "auto"),
        }
        opts["clip_seconds"] = max(10, min(opts["clip_seconds"], 180))
        opts["max_clips"] = max(1, min(opts["max_clips"], 30))
        with LOCK:
            JOBS[job_id] = {"status": "queued", "filename": secure_filename(f.filename), "info": info}
        threading.Thread(target=run_job, args=(job_id, source, opts), daemon=True).start()
        return redirect(url_for("job", job_id=job_id))
    return render_template("index.html")

@app.route("/job/<job_id>")
def job(job_id):
    if job_id not in JOBS: return "Job not found", 404
    return render_template("job.html", job_id=job_id, job=JOBS[job_id])

@app.route("/api/job/<job_id>")
def job_api(job_id):
    if job_id not in JOBS: return jsonify({"error":"not found"}), 404
    return jsonify(JOBS[job_id])

@app.route("/download/<job_id>")
def download(job_id):
    job = JOBS.get(job_id)
    if not job or job.get("status") != "done": return "Not ready", 404
    return send_file(job["zip"], as_attachment=True, download_name=f"clipforge-{job_id}.zip")

@app.route("/health")
def health(): return {"ok": True, "app": "ClipForge"}

if __name__ == "__main__":
    # Local-only by default. On Android, open http://127.0.0.1:5000 in Chrome.
    app.run(host="127.0.0.1", port=5000, debug=False, threaded=True)
