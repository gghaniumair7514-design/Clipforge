# ClipForge — Android-first free video clipper

ClipForge is a self-hosted Flask app that runs locally on Android through Termux. It splits long videos into short MP4 clips, ranks candidate windows using audio silence/activity and scene-change signals, crops to vertical/square/landscape formats, and can optionally burn subtitles using faster-whisper.

## What it does
- Local browser interface; no account, cloud upload, paid API, or subscription.
- MP4/MOV/MKV/WEBM/AVI/M4V input (FFmpeg-supported formats).
- 15–180 second clips; up to 30 clips per job.
- Smart highlight heuristic: prioritizes active audio and visual scene changes.
- Even-interval mode.
- 9:16, 1:1, and 16:9 output.
- Optional face-aware crop (requires OpenCV; otherwise falls back to center crop).
- Optional Whisper subtitles (requires extra installation and a model download).
- ZIP download with clips and JSON report.

**Honest limitation:** the included "smart highlights" is a lightweight heuristic, not a trained viral-moment predictor. It does not understand story context or guarantee virality. The optional Whisper package is not installed by default because it is large and can be slow on phones.

## Android installation (free)
1. Install **Termux from F-Droid** (recommended source): https://f-droid.org/packages/com.termux/
2. Open Termux and run:

```bash
pkg update -y && pkg upgrade -y
pkg install -y python ffmpeg git
```

3. Clone your GitHub repository (replace `YOUR_USERNAME`):

```bash
git clone https://github.com/YOUR_USERNAME/clipforge.git
cd clipforge
```

4. Create a Python environment and install dependencies:

```bash
python -m venv .venv
source .venv/bin/activate
pip install --upgrade pip
pip install -r requirements-android.txt
```

5. Start ClipForge:

```bash
python app.py
```

6. Open Chrome on the same phone and visit:

```text
http://127.0.0.1:5000
```

Choose a video, settings, and tap **Create my clips**. When finished, download the ZIP.

## Access videos stored on your phone
Termux storage permission:

```bash
termux-setup-storage
```

Allow access when Android asks. In the browser upload picker, choose a video from your phone. You can also copy videos into Termux shared storage if needed.

## Optional: enable subtitles
This is optional and may be too heavy for low-memory phones. It downloads a Whisper model on first use and requires extra storage/RAM.

```bash
pip install faster-whisper
```

Restart the app and tick **Generate subtitles**. The default model is `tiny` and processing is CPU-based. Urdu recognition quality may vary. If installation fails on your Android device, use ClipForge without subtitles or run the same project on a PC.

## Optional: face-aware crop
The code uses OpenCV Haar face detection if `opencv-python` is installed. On Android, OpenCV installation may fail or consume significant storage. Without it, the app uses center crop automatically. Install only if a compatible wheel is available:

```bash
pip install opencv-python
```

## Run on a computer
Install Python 3.10+ and FFmpeg, then:

```bash
pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:5000`.

## GitHub upload
Create a public repository named `clipforge`, then upload all files and folders from this project. Do not upload `uploads/`, `outputs/`, `.venv/`, or personal videos.

## Troubleshooting
- `ffmpeg: not found`: run `pkg install ffmpeg` in Termux.
- Port already in use: stop the old server with `Ctrl+C`, then restart.
- Processing is slow: use 720p input, fewer clips, and 15–30 second clips; keep the phone charging and screen awake.
- Out of storage: delete old files in `uploads/` and `outputs/`.
- Browser cannot connect: make sure the Termux server is still running and use exactly `http://127.0.0.1:5000`.
- App stops in background: Android may kill Termux; keep Termux open while processing.

## Privacy and safety
All processing is local by default. Uploaded videos remain in the project's `uploads/` folder until manually deleted. Do not expose the Flask server to the public internet without adding authentication, upload limits, and secure deployment settings.

## License
MIT — see `LICENSE`.
